window.MF_CITIES=[["delhi",28.6139,77.209,1],["mumbai",19.076,72.8777,1],["bengaluru",12.9716,77.5946,1],["kolkata",22.5726,88.3639,1],["chennai",13.0827,80.2707,1],["hyderabad",17.385,78.4867,1],["ahmedabad",23.0225,72.5714,1],["pune",18.5204,73.8567,1],["jaipur",26.9124,75.7873,1],["lucknow",26.8467,80.9462,1],["surat",21.1702,72.8311,1],["kanpur",26.4499,80.3319,1],["nagpur",21.1458,79.0882,1],["indore",22.7196,75.8577,1],["bhopal",23.2599,77.4126,1],["patna",25.5941,85.1376,1],["vadodara",22.3072,73.1812,1],["ghaziabad",28.6692,77.4538,1],["ludhiana",30.901,75.8573,1],["agra",27.1767,78.0081,1],["nashik",19.9975,73.7898,1],["faridabad",28.4089,77.3178,1],["meerut",28.9845,77.7064,1],["rajkot",22.3039,70.8022,1],["varanasi",25.3176,82.9739,1],["srinagar",34.0837,74.7973,1],["amritsar",31.634,74.8723,1],["prayagraj",25.4358,81.8463,1],["ranchi",23.3441,85.3096,1],["jodhpur",26.2389,73.0243,1],["raipur",21.2514,81.6296,1],["gwalior",26.2183,78.1828,1],["chandigarh",30.7333,76.7794,1],["guwahati",26.1445,91.7362,1],["kota",25.2138,75.8648,1],["jabalpur",23.1815,79.9864,1],["gurugram",28.4595,77.0266,1],["noida",28.5355,77.391,1],["dehradun",30.3165,78.0322,1],["bhubaneswar",20.2961,85.8245,1],["visakhapatnam",17.6868,83.2185,1],["coimbatore",11.0168,76.9558,1],["madurai",9.9252,78.1198,1],["kochi",9.9312,76.2673,1],["thiruvananthapuram",8.5241,76.9366,1],["vijayawada",16.5062,80.648,1],["aurangabad",19.8762,75.3433,1],["udaipur",24.5854,73.7125,1],["ajmer",26.4499,74.6399,1],["bikaner",28.0229,73.3119,1],["bareilly",28.367,79.4304,1],["aligarh",27.8974,78.088,1],["moradabad",28.8386,78.7733,1],["gorakhpur",26.7606,83.3732,1],["jammu",32.7266,74.857,1],["shimla",31.1048,77.1734,1],["haridwar",29.9457,78.1642,1],["ujjain",23.1765,75.7885,1],["jalandhar",31.326,75.5762,1],["panipat",29.3909,76.9635,1],["mysuru",12.2958,76.6394,0],["mangaluru",12.9141,74.856,0],["hubballi",15.3647,75.124,0],["belagavi",15.8497,74.4977,0],["tiruchirappalli",10.7905,78.7047,0],["salem",11.6643,78.146,0],["puducherry",11.9416,79.8083,0],["kozhikode",11.2588,75.7804,0],["thrissur",10.5276,76.2144,0],["tirupati",13.6288,79.4192,0],["guntur",16.3067,80.4365,0],["warangal",17.9689,79.5941,0],["solapur",17.6599,75.9064,0],["kolhapur",16.705,74.2433,0],["thane",19.2183,72.9781,0],["navi-mumbai",19.033,73.0297,0],["amravati",20.9374,77.7796,0],["panaji",15.4909,73.8278,0],["bhavnagar",21.7645,72.1519,0],["jamnagar",22.4707,70.0577,0],["gandhinagar",23.2156,72.6369,0],["jhansi",25.4484,78.5685,0],["mathura",27.4924,77.6737,0],["ayodhya",26.7922,82.1998,0],["saharanpur",29.964,77.546,0],["rohtak",28.8955,76.6066,0],["hisar",29.1492,75.7217,0],["patiala",30.3398,76.3869,0],["bathinda",30.211,74.9455,0],["gaya",24.7914,85.0002,0],["bhagalpur",25.2425,86.9842,0],["muzaffarpur",26.1209,85.3647,0],["jamshedpur",22.8046,86.2029,0],["dhanbad",23.7957,86.4304,0],["cuttack",20.4625,85.883,0],["siliguri",26.7271,88.3953,0],["durgapur",23.5204,87.3119,0],["bilaspur",22.0797,82.1409,0],["imphal",24.817,93.9368,0],["shillong",25.5788,91.8933,0],["agartala",23.8315,91.2868,0],["port-blair",11.6234,92.7265,0]];
/* Moon Finder – small site script (theme, countdowns, city picker, sharing) */
(function () {
  'use strict';
  var CITIES = window.MF_CITIES || [];
  var root = document.documentElement;

  // Theme
  var btn = document.getElementById('themeBtn');
  function setTheme(t) { root.dataset.theme = t; if (btn) btn.textContent = t === 'dark' ? '☀' : '☾'; }
  setTheme(root.dataset.theme === 'dark' ? 'dark' : 'light');
  if (btn) btn.addEventListener('click', function () {
    var t = root.dataset.theme === 'dark' ? 'light' : 'dark';
    setTheme(t);
    try { localStorage.setItem('mf-theme', t); } catch (e) {}
  });

  // Countdowns
  var cds = document.querySelectorAll('[data-ts]');
  function tick() {
    var now = Date.now();
    cds.forEach(function (el) {
      var hi = el.getAttribute('data-lang') === 'hi';
      var d = Number(el.getAttribute('data-ts')) - now;
      if (d <= 0) {
        if (d > -12 * 3600e3) { el.textContent = hi ? '✨ अभी / आज' : '✨ Now / today'; el.hidden = false; }
        else el.hidden = true;
        return;
      }
      var m = Math.floor(d / 60000), days = Math.floor(m / 1440), h = Math.floor((m % 1440) / 60), mi = m % 60;
      var txt;
      if (hi) txt = '⏳ ' + (days ? days + ' दिन ' + h + ' घंटे' : h ? h + ' घंटे ' + mi + ' मिनट' : mi + ' मिनट') + ' बाकी';
      else txt = '⏳ in ' + (days ? days + 'd ' + h + 'h' : h ? h + 'h ' + mi + 'm' : mi + 'm');
      el.textContent = txt; el.hidden = false;
    });
  }
  if (cds.length) { tick(); setInterval(tick, 30000); }

  // City select navigation
  document.querySelectorAll('select[data-nav]').forEach(function (s) {
    s.addEventListener('change', function () { if (s.value) location.href = s.value; });
  });

  // Nearest city
  document.querySelectorAll('[data-near]').forEach(function (b) {
    b.addEventListener('click', function () {
      if (!navigator.geolocation) return;
      var label = b.textContent; b.textContent = '…';
      navigator.geolocation.getCurrentPosition(function (p) {
        var lat = p.coords.latitude, lng = p.coords.longitude, best = null, bd = Infinity, onlyTop = b.getAttribute('data-top') === '1';
        CITIES.forEach(function (c) {
          if (onlyTop && !c[3]) return;
          var dx = (c[2] - lng) * Math.cos(lat * Math.PI / 180), dy = c[1] - lat, dd = dx * dx + dy * dy;
          if (dd < bd) { bd = dd; best = c; }
        });
        if (best) location.href = b.getAttribute('data-near').replace('__CITY__', best[0]);
        else b.textContent = label;
      }, function () { b.textContent = label; }, { timeout: 10000, maximumAge: 600000 });
    });
  });

  // Table filter
  document.querySelectorAll('input[data-filter]').forEach(function (inp) {
    var table = document.querySelector(inp.getAttribute('data-filter'));
    if (!table) return;
    inp.addEventListener('input', function () {
      var q = inp.value.trim().toLowerCase();
      table.querySelectorAll('tbody tr').forEach(function (tr) { tr.hidden = q && tr.textContent.toLowerCase().indexOf(q) < 0; });
    });
  });

  // Copy link
  document.querySelectorAll('[data-copy]').forEach(function (b) {
    b.addEventListener('click', function () {
      var href = b.getAttribute('data-copy');
      if (navigator.share) { navigator.share({ url: href, title: document.title }).catch(function () {}); return; }
      if (navigator.clipboard) navigator.clipboard.writeText(href).then(function () { b.textContent = '✓'; });
    });
  });
})();
